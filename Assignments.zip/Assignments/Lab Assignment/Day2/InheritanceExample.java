package Day2;

public class InheritanceExample {
    public static void main(String []args){
        Bike M=new Bike();
    }

}
