package Day2;

public class A
{
	int p;
	int q;
	int r;
	public A(int p, int q, int r) {
		super();
		this.p = p;
		this.q = q;
		this.r = r;
	}
	public int getP() {
		return p;
	}
	public void setP(int p) {
		this.p = p;
	}
	public int getQ() {
		return q;
	}
	public void setQ(int q) {
		this.q = q;
	}
	public int getR() {
		return r;
	}
	public void setR(int r) {
		this.r = r;
	}
	
}
