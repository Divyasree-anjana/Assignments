package Day2;
import java.util.Scanner;
public class Use 
{
	public static void main(String... args) 
	{
		Scanner s=new Scanner(System.in);

	}
}
