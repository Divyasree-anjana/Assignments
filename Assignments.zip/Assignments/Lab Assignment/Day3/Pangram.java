package Day3;

import java.util.Scanner;

public class Pangram {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		//System.out.println("Enter a string:");
		//String str=(s.nextLine()).toLowerCase();
		System.out.println((int)'a');
		//System.out.println("Given String in lower case is "+str);
		
		

	}

}
