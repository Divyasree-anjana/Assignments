package DAY4;

public interface AdvancedArithmetic {
	int divisor_sum(int n);
}
